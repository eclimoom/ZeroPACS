ublas
=====

The Boost.uBLAS Linear Algebra Library v1.0

- To follow development and test experimental features, you can clone the Github project uBLAS/ublas
at https://github.com/uBLAS/ublas
- A development wiki is available at https://github.com/uBLAS/ublas/wiki
- A mailing-list is available at http://lists.boost.org/ublas/
- For any other questions, you can contact David at david.bellot@gmail.com

- version numbers have never been used for this library until 02 March 2014.
  So we start at v1.0 on that day.

last update: 1 April 2014
